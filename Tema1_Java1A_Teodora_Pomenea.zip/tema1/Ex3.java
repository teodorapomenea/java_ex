public class Ex3
{
    public static void main (String[] args){
    Student[] s = new Student[5];
    s[0] = new Student("Ana",'C');
    s[1] = new Student("Alina",'B');
    s[2] = new Student("Andrei",'A');
    s[3] = new Student("Ioana",'C');
    s[4] = new Student("Ion",'D');
    for(int i=0;i<s.length;i++)
        if(s[i].serie=='C') System.out.println(s[i].getMedie());
    } 
}
