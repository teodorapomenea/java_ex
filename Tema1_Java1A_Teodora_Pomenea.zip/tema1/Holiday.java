public class Holiday
{
   String nume;
   int ziua;
   String luna;
   
   public Holiday(String nume,int ziua,String luna){
       this.nume=nume;
       this.ziua=ziua;
       this.luna=luna;
    }
    
    public Holiday (){
         this("Necunoscut",1,"Nicio luna");
    }
   
    public boolean inSameDay(Holiday h1,Holiday h2){
        if(h1.ziua == h2.ziua) return true;
        else return false;   
    }
    
}
