public class Student{
    String nume;
    int grupa;
    char serie;
    int an;
    String facultate;
    double[] note={7, 8, 4, 6, 10, 9, 9, 8, 6, 5};
    
    
    public Student(){}
 
    
    public Student(String nume, int grupa , String facultate, int an){
    this.nume=nume;
    this.grupa=grupa;
    this.facultate=facultate;
    this.an=an;
    }
    
    public Student(String nume, char serie){
    this.nume=nume;
    this.serie=serie;
    }
    
    public void sePrezinta(){
    System.out.println(this.nume+" "+this.facultate+" "+this.grupa);
    }
    
    public boolean esteIntegralist(){
        boolean k=true;
        for(int i=0;i<10;i++)
        if(note[i] < 5)
            {k=false;
             break;
            }
        return k;
    }
    
    public double getMedie()
    {  double m=0 ;
       for(int i=0;i<10;i++)
       m+=note[i];
       m=m/10;
       return m;
    }
    
    public double getMin()
    { double min=note[0];
      for(int i=1;i<10;i++)
      if (note[i]<note[i-1]) min=note[i];
      return min;  
    }
    
     public double getMax()
    { double max=note[0];
      for(int i=1;i<10;i++)
      if (note[i]>note[i-1]) max=note[i];
      return max;  
    }
    
    public double sumaPare()
    { double s=0;
     for(int i=0;i<10;i++)
      if (note[i]%2==0) s+=note[i];
     return s;  
    }
    
    public double produsDiv3() 
    { double p=1;
        for(int i=0;i<10;i++)
            if (note[i]%3==0) p=p*note[i];
        return p; 
    }
}
    
    
    
